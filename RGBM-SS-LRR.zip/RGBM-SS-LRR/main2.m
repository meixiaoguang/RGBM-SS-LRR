clc;
clear;
close all;
addpath(genpath(cd));
warning off;

load Cuprite_Norm.mat;
imshow(imag_norm(:,:,[10, 100, 160]));
[Row, Col, C] = size(imag_norm);
Y = reshape(imag_norm, Row*Col, C)';
M = 3;
P = Row*Col;


%% ============================VCA-FCLS==============================================
disp('VCA-FCLS');
[E1, location, y] = VCA(Y, 'Endmembers',M, 'verbose', 'no');
A1 = Fcls(Y, E1);
[SAD1,AVG_SAD1, RE1] = angle_gbm( Y, E1*A1 );


%% ============================RGBM-SS-LRR==============================================
disp('RGBM-SS-LRR');
mu = 1e-2;
tol = 1e-6;
maxiter = 1000;
K = 100;
lambda = [0 10.^(-6:1:-1)];
alpha = [0 10.^(-6:1:-1)];

no_l1 = size(lambda,2);
no_l2 = size(alpha,2);

Y_3D = reshape(Y', Row, Col, C);
for j1=1:no_l1
    j1
    for j2 = 1:no_l2
        tic
        [Results2{j1,j2}] = RGBM_SS_LRR(Y_3D, E1, K, lambda(j1), alpha(j2), mu, tol, maxiter);
        t2(j1,j2) = toc
        [SAD2(j1,j2,:),AVG_SAD2(j1,j2), RE2(j1,j2)] = angle_gbm( Y, Results2{j1,j2}.Y);
    end
end